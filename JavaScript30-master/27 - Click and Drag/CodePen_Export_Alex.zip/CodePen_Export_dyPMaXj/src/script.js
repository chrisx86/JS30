const list = document.querySelector(".items");
      let startX = 0;
      let startScroll = 0;
      let startTime = 0;
      let moved = false;
      const startDrag = function(e) {
        list.classList.add("active");
        startX = e.pageX;
        startScroll = list.scrollLeft;
        startTime = new Date().getTime();
        moved = false;
      };
      const dragHandler = function(e) {
        e.preventDefault();
        if (list.classList.contains("active")) {
          moved = true;
          let move = e.pageX - startX;
          // startX = e.pageX;
          // list.scrollLeft -= move * 5;
          list.scrollLeft = startScroll - move * 5;
        }
      };
      const stopDrag = function(e) {
        list.classList.remove("active");
        if (new Date().getTime() - startTime <= 250) {
          if (e.pageX > startX) {
            console.log("swipe right");
          } else if (e.pageX < startX) {
            console.log("swipe left");
          }
        }
      };
      list.addEventListener("mousedown", startDrag); //touchstart
      list.addEventListener("mousemove", dragHandler); //touchmove
      list.addEventListener("mouseup", stopDrag); //touchend
      list.addEventListener("mouseleave", stopDrag);

      document.querySelectorAll(".items a").forEach(dom => {
        dom.addEventListener("click", function(e) {
          if (moved) {
            e.preventDefault();
          }
        });
      });